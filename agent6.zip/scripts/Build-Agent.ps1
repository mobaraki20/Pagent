param(
  [string]$Configuration='Release',
  [string]$Runtime='win-x64',
  [string]$Output=(Join-Path $PSScriptRoot '..\artifacts')
)
$ErrorActionPreference='Stop'
$root=(Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$version='6.0.0'
$dotnet=(Get-Command dotnet -ErrorAction Stop).Source
Push-Location $root
try {
$sdk=& $dotnet --version
if(-not $sdk.StartsWith('10.')){throw ".NET 10 SDK required; found $sdk"}

Remove-Item $Output -Recurse -Force -ErrorAction SilentlyContinue
New-Item $Output -ItemType Directory -Force|Out-Null

& $dotnet restore (Join-Path $root 'Sokna.PrintAgent.slnx')
if($LASTEXITCODE -ne 0){throw 'dotnet restore failed.'}
& $dotnet build (Join-Path $root 'Sokna.PrintAgent.slnx') -c $Configuration --no-restore
if($LASTEXITCODE -ne 0){throw 'dotnet build failed.'}
& $dotnet run --project (Join-Path $root 'tests\Sokna.PrintAgent.Tests\Sokna.PrintAgent.Tests.csproj') -c $Configuration --no-build
if($LASTEXITCODE -ne 0){throw 'Agent tests failed.'}

foreach($project in @('Sokna.PrintAgent.Service','Sokna.PrintAgent.Worker','Sokna.PrintAgent.Control')){
  $proj=Join-Path $root "src\$project\$project.csproj"
  $dest=Join-Path $Output $project
  & $dotnet restore $proj -r $Runtime
  if($LASTEXITCODE -ne 0){throw "dotnet runtime restore failed: $project"}
  & $dotnet publish $proj -c $Configuration -r $Runtime --self-contained true --no-restore -o $dest
  if($LASTEXITCODE -ne 0){throw "dotnet publish failed: $project"}
}

$package=Join-Path $Output 'package'
$payload=Join-Path $package 'payload'
$docs=Join-Path $package 'docs'
New-Item $payload -ItemType Directory -Force|Out-Null
New-Item $docs -ItemType Directory -Force|Out-Null

# The installed uninstaller is part of the verified payload and survives Setup extraction.
Copy-Item (Join-Path $root 'installer\Uninstall-SoknaPrintAgent.ps1') (Join-Path $payload 'Uninstall-SoknaPrintAgent.ps1') -Force

# All executables deliberately share one install directory. File names are project-qualified; common
# runtime dependencies must be byte-identical when overwritten by another published project.
$collisionHashes=@{}
foreach($project in @('Sokna.PrintAgent.Service','Sokna.PrintAgent.Worker','Sokna.PrintAgent.Control')){
  $src=Join-Path $Output $project
  Get-ChildItem $src -File | ForEach-Object {
    $name=$_.Name;$hash=(Get-FileHash $_.FullName -Algorithm SHA256).Hash
    if($collisionHashes.ContainsKey($name) -and $collisionHashes[$name] -ne $hash){throw "Published file collision with different content: $name"}
    $collisionHashes[$name]=$hash
    Copy-Item $_.FullName (Join-Path $payload $name) -Force
  }
}

Copy-Item (Join-Path $root 'installer\Install-SoknaPrintAgent.ps1') $package
Copy-Item (Join-Path $root 'installer\Uninstall-SoknaPrintAgent.ps1') $package
Copy-Item (Join-Path $root 'README_FA.md') $package
Copy-Item (Join-Path $root 'docs\*.md') $docs
Set-Content (Join-Path $package 'VERSION.txt') $version -Encoding utf8NoBOM

$manifest=@()
Get-ChildItem $payload -File -Recurse | Sort-Object FullName | ForEach-Object {
  $relative=[IO.Path]::GetRelativePath($package,$_.FullName).Replace('\\','/')
  $manifest += [ordered]@{path=$relative;size=$_.Length;sha256=(Get-FileHash $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}
}
$manifest | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $package 'PAYLOAD_MANIFEST.json') -Encoding utf8NoBOM

$buildInfo=[ordered]@{
  agent_version=$version;protocol_version=4;runtime=$Runtime;configuration=$Configuration
  dotnet_sdk=$sdk;built_at_utc=(Get-Date).ToUniversalTime().ToString('o')
  target_framework='net10.0-windows10.0.19041.0';self_contained=$true
}
$buildInfo | ConvertTo-Json -Depth 4 | Set-Content (Join-Path $package 'BUILD_INFO.json') -Encoding utf8NoBOM

$zip=Join-Path $Output "Sokna-Print-Agent-$version-$Runtime.zip"
Compress-Archive -Path (Join-Path $package '*') -DestinationPath $zip -CompressionLevel Optimal

# Build a single-file Windows bootstrapper with the verified package embedded.
$setupOut=Join-Path $Output 'Setup'
New-Item $setupOut -ItemType Directory -Force|Out-Null
$setupProject=Join-Path $root 'src\Sokna.PrintAgent.Setup\Sokna.PrintAgent.Setup.csproj'
& $dotnet restore $setupProject -r $Runtime
if($LASTEXITCODE -ne 0){throw 'dotnet runtime restore failed: Sokna.PrintAgent.Setup'}
& $dotnet publish $setupProject -c $Configuration -r $Runtime --self-contained true --no-restore `
  "-p:PayloadZip=$zip" -p:PublishSingleFile=true -o $setupOut
if($LASTEXITCODE -ne 0){throw 'dotnet publish failed: Sokna.PrintAgent.Setup'}
$setupExe=Join-Path $setupOut "Sokna-Print-Agent-$version-Setup.exe"
if(-not (Test-Path $setupExe -PathType Leaf)){throw "Setup executable was not produced: $setupExe"}
$setupFinal=Join-Path $Output ([IO.Path]::GetFileName($setupExe))
Copy-Item $setupExe $setupFinal -Force

$artifactRows=@()
foreach($artifact in @($zip,$setupFinal)){
  $artifactRows += [ordered]@{
    file=[IO.Path]::GetFileName($artifact)
    size=(Get-Item $artifact).Length
    sha256=(Get-FileHash $artifact -Algorithm SHA256).Hash.ToLowerInvariant()
  }
}
$artifactRows | ConvertTo-Json -Depth 4 | Set-Content (Join-Path $Output "BUILD_ARTIFACTS-Agent-$version.json") -Encoding utf8NoBOM
$artifactRows | ForEach-Object { "$($_.sha256)  $($_.file)" } | Set-Content (Join-Path $Output "SHA256SUMS-Agent-$version.txt") -Encoding ascii
$artifactRows | ForEach-Object { Write-Host "Built: $($_.file) | $($_.size) bytes | SHA256=$($_.sha256)" -ForegroundColor Green }
}
finally { Pop-Location }
