using System.Diagnostics;
using System.Security.Principal;
using System.Text.Json;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Sokna.PrintAgent.Core;
namespace Sokna.PrintAgent.Service;

public sealed class PrintAgentService:BackgroundService
{
    private const string AgentVersion="6.0.0";
    private readonly AgentPaths _paths;private readonly LocalQueueStore _store;private readonly IPrinterHealthProvider _printers;private readonly ILogger<PrintAgentService> _log;private readonly AgentLog _fileLog;
    private readonly DateTimeOffset _started=DateTimeOffset.UtcNow;private readonly Mutex _mutex=new(false,@"Global\SoknaPrintAgentV6Service");
    private AgentOptions _options=new();private IPrintTransport? _api;private HttpClient? _http;private DateTime _configStampUtc=DateTime.MinValue,_secretStampUtc=DateTime.MinValue;
    private DateTimeOffset? _lastPoll,_lastSubmission;private DateTimeOffset _nextHeartbeat=DateTimeOffset.MinValue,_nextDestinationRefresh=DateTimeOffset.MinValue;private IReadOnlyList<DestinationConfig> _destinations=[];

    public PrintAgentService(AgentPaths paths,LocalQueueStore store,IPrinterHealthProvider printers,ILogger<PrintAgentService> log,AgentLog fileLog)
    {_paths=paths;_store=store;_printers=printers;_log=log;_fileLog=fileLog;}

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if(!_mutex.WaitOne(TimeSpan.Zero))throw new InvalidOperationException("نمونه دیگری از Sokna Print Agent فعال است.");
        try
        {
            await _store.InitializeAsync(stoppingToken);
            await RecoverAsync(stoppingToken);
            await WriteLocalHealthAsync("starting",false,File.Exists(_paths.SecretPath),null,stoppingToken);
            while(!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    if(!await EnsureConfiguredAsync(stoppingToken))
                    {
                        await Task.Delay(TimeSpan.FromSeconds(2),stoppingToken);continue;
                    }
                    await MaybeRefreshDestinationsAsync(stoppingToken);
                    await FlushReportsAsync(stoppingToken);
                    await AcceptAnyReservedAsync(stoppingToken);
                    var processed=await ProcessOneAsync(stoppingToken);
                    if(!processed)await ClaimAsync(stoppingToken);
                    _lastPoll=DateTimeOffset.UtcNow;
                    await MaybeHeartbeatAsync(stoppingToken);
                    await WriteLocalHealthAsync("running",true,true,null,stoppingToken);
                    await Task.Delay(processed?_options.ActivePollMilliseconds:_options.IdlePollMilliseconds,stoppingToken);
                }
                catch(OperationCanceledException) when(stoppingToken.IsCancellationRequested){break;}
                catch(Exception e)
                {
                    LogSafe("poll",e);await WriteLocalHealthAsync("degraded",_api is not null,File.Exists(_paths.SecretPath),Safe(e.Message),stoppingToken);
                    await Task.Delay(TimeSpan.FromSeconds(3),stoppingToken);
                }
            }
        }
        finally
        {
            try{await WriteLocalHealthAsync("stopped",_api is not null,File.Exists(_paths.SecretPath),null,CancellationToken.None);}catch{}
            _http?.Dispose();_mutex.ReleaseMutex();
        }
    }

    private async Task<bool> EnsureConfiguredAsync(CancellationToken ct)
    {
        var configExists=File.Exists(_paths.ConfigPath);var secretExists=File.Exists(_paths.SecretPath);
        if(!configExists||!secretExists)
        {
            _api=null;_destinations=[];var missing=!configExists&&!secretExists?"config و token":!configExists?"config":"token";
            await WriteLocalHealthAsync("waiting_for_configuration",configExists,secretExists,$"در انتظار {missing}.",ct);return false;
        }
        var configStamp=File.GetLastWriteTimeUtc(_paths.ConfigPath);var secretStamp=File.GetLastWriteTimeUtc(_paths.SecretPath);
        if(_api is not null&&configStamp==_configStampUtc&&secretStamp==_secretStampUtc)return true;
        try
        {
            var options=AgentOptions.Load(_paths.ConfigPath);options.Validate();var token=SecretStore.Load(_paths.SecretPath);if(string.IsNullOrWhiteSpace(token))throw new InvalidDataException("Agent token خالی است.");
            var http=new HttpClient();var api=new HttpPrintTransport(http,options.ServerBaseUrl,token);
            var probe=await api.ProbeAsync(ct);if(!probe.Success||probe.ProtocolVersion!=4)throw new InvalidOperationException("Print API v4 آماده نیست.");
            _http?.Dispose();_http=http;_api=api;_options=options;_destinations=probe.Destinations;_configStampUtc=configStamp;_secretStampUtc=secretStamp;_nextDestinationRefresh=DateTimeOffset.UtcNow.AddSeconds(30);_nextHeartbeat=DateTimeOffset.MinValue;
            _fileLog.Info("configured",$"Print API v4 فعال شد؛ {probe.Destinations.Count} مقصد دریافت شد.");return true;
        }
        catch(Exception e)
        {
            _api=null;_destinations=[];LogSafe("configuration",e);await WriteLocalHealthAsync("configuration_error",true,true,Safe(e.Message),ct);return false;
        }
    }

    private async Task MaybeRefreshDestinationsAsync(CancellationToken ct)
    {
        if(_api is null||DateTimeOffset.UtcNow<_nextDestinationRefresh)return;
        var probe=await _api.ProbeAsync(ct);if(!probe.Success||probe.ProtocolVersion!=4)throw new InvalidOperationException("Print API v4 آماده نیست.");
        _destinations=probe.Destinations;_nextDestinationRefresh=DateTimeOffset.UtcNow.AddSeconds(30);
    }

    private async Task RecoverAsync(CancellationToken ct)
    {
        foreach(var job in await _store.GetRecoverableAsync(ct))
        {
            if(job.State is LocalJobState.WorkerLaunching)
            {
                var result=await TryReadWorkerResultAsync(job,ct);
                if(result is not null){await ApplyWorkerResultAsync(job,result,ct);CleanupWorkerFiles(job);continue;}
                if(File.Exists(FencePath(job)))
                    await QueueReportAsync(job,"recovery_hold",null,false,"service_restart_after_submission_fence","Service پس از Submission Fence بازیابی شد و نتیجه قابل اثبات نیست.",ct);
                else
                    await _store.SetStateAsync(job.AttemptId,LocalJobState.Claimed,error:"Worker قبل از Submission Fence متوقف شده بود؛ ادامه ایمن است.",ct:ct);
            }
            else if(job.State is LocalJobState.Submitted or LocalJobState.ReportPending)
                await QueueReportAsync(job,"submitted",job.SpoolerJobId,false,null,null,ct);
            else if(job.State==LocalJobState.Unknown)
                await QueueReportAsync(job,"unknown",job.SpoolerJobId,false,"recovered_unknown",job.LastError,ct);
            else if(job.State==LocalJobState.RecoveryHold)
                await QueueReportAsync(job,"recovery_hold",job.SpoolerJobId,false,"recovered_hold",job.LastError,ct);
            else if(job.State==LocalJobState.SafeFailed)
                await QueueReportAsync(job,"failed",null,true,"recovered_pre_submit_failure",job.LastError,ct);
        }
    }

    private async Task ClaimAsync(CancellationToken ct)
    {
        if(_api is null||_destinations.Count==0)return;
        var health=SafeQueues();var ready=_destinations.Where(d=>health.Any(p=>QueueReady(p,d.WindowsQueueName))).Select(d=>d.DestinationKey).ToArray();if(ready.Length==0)return;
        var response=await _api.ClaimAsync(CryptoUtil.NewRequestId(),ready,_options.ClaimBatchSize,ct);
        foreach(var item in response.Jobs)
            await _store.PersistReservedAsync(item,CryptoUtil.NewLocalReceiptId(),ct);
    }

    private async Task AcceptAnyReservedAsync(CancellationToken ct)
    {
        if(_api is null)return;
        foreach(var local in (await _store.GetRecoverableAsync(ct)).Where(x=>x.State==LocalJobState.Reserved).OrderBy(x=>x.ServerJobId).ThenBy(x=>x.AttemptNo))
        {
            if(local.LeaseExpiresAt<=DateTimeOffset.UtcNow){await _store.SetStateAsync(local.AttemptId,LocalJobState.Resolved,error:"Lease محلی پیش از Accept منقضی شد؛ Server Attempt جدید خواهد ساخت.",ct:ct);continue;}
            var destination=new DestinationConfig(local.DestinationKey,local.DestinationKey,local.QueueName,local.PaperWidthMm,local.PrintableWidthMm,local.Copies,local.LayoutMode);
            var item=new ClaimItem(new((int)local.ServerJobId,"","",false,null,null,"",4,local.ContentSha256,local.PayloadJson),new(local.AttemptId,local.AttemptNo,SecretStore.UnprotectText(local.ProtectedLeaseToken),""),destination);
            var result=await _api.AcceptAsync(item,local.LocalReceiptId,CryptoUtil.NewRequestId(),ct);
            if(result.Success)await _store.SetStateAsync(local.AttemptId,LocalJobState.Claimed,ct:ct);
        }
    }

    private async Task<bool> ProcessOneAsync(CancellationToken ct)
    {
        if(_api is null)return false;
        var queues=SafeQueues();var open=await _store.GetRecoverableAsync(ct);
        var job=open.Where(x=>x.State==LocalJobState.Claimed)
            .OrderBy(x=>x.ServerJobId).ThenBy(x=>x.AttemptNo)
            .FirstOrDefault(candidate=>queues.Any(q=>QueueReady(q,candidate.QueueName))
                && !open.Any(older=>string.Equals(older.DestinationKey,candidate.DestinationKey,StringComparison.OrdinalIgnoreCase)
                    && older.ServerJobId<candidate.ServerJobId));
        if(job is null)return false;
        try
        {
            var started=await _api.StartAsync(job,CryptoUtil.NewRequestId(),ct);if(!started.Success)return false;
        }
        catch(PrintApiException e) when(e.Terminal)
        {
            // Server is authoritative: a terminal attempt must never be re-authorized locally.
            // Resolve the stale local ownership without printing; unknown/recovery_hold remain visible on Server.
            await _store.SetStateAsync(job.AttemptId,LocalJobState.Resolved,error:$"Server state: {e.CurrentState ?? "terminal"}",ct:ct);
            _fileLog.Info("start_fenced",$"Attempt {job.AttemptId} local claim resolved without printing; server state={e.CurrentState ?? "terminal"}.");
            return true;
        }

        CleanupTransientBeforeLaunch(job);
        var input=new WorkerInput(job.ServerJobId,job.AttemptId,job.LocalReceiptId,job.QueueName,job.PayloadJson,job.ContentSha256,job.PaperWidthMm,job.PrintableWidthMm,job.Copies,ResultPath(job),FencePath(job),StartSignalPath(job));
        await DurableFile.WriteJsonAtomicAsync(InputPath(job),input,ct);
        await _store.SetStateAsync(job.AttemptId,LocalJobState.WorkerLaunching,markWorkerLaunching:true,ct:ct);

        var worker=Path.Combine(AppContext.BaseDirectory,"Sokna.PrintAgent.Worker.exe");
        var psi=new ProcessStartInfo(worker,$"\"{InputPath(job)}\""){UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=AppContext.BaseDirectory,RedirectStandardError=true};
        using var process=Process.Start(psi)??throw new InvalidOperationException("PrintWorker اجرا نشد.");
        using var guard=WorkerProcessGuard.Attach(process);
        await DurableFile.TouchAtomicAsync(StartSignalPath(job),$"start:{job.AttemptId}",ct);
        using var timeout=CancellationTokenSource.CreateLinkedTokenSource(ct);timeout.CancelAfter(TimeSpan.FromSeconds(_options.WorkerTimeoutSeconds));
        try{await process.WaitForExitAsync(timeout.Token);}
        catch(OperationCanceledException) when(!ct.IsCancellationRequested)
        {
            TryKill(process);var durable=await TryReadWorkerResultAsync(job,CancellationToken.None);
            if(durable is not null)await ApplyWorkerResultAsync(job,durable,CancellationToken.None);
            else if(File.Exists(FencePath(job)))await QueueReportAsync(job,"recovery_hold",null,false,"worker_timeout_after_fence","PrintWorker پس از Submission Fence Timeout شد؛ Retry خودکار ممنوع است.",CancellationToken.None);
            else await QueueReportAsync(job,"failed",null,true,"worker_timeout_before_fence","PrintWorker پیش از Submission Fence Timeout شد؛ Retry ایمن مجاز است.",CancellationToken.None);
            CleanupWorkerFiles(job);return true;
        }
        catch(OperationCanceledException) when(ct.IsCancellationRequested){throw;}

        var result=await TryReadWorkerResultAsync(job,ct);
        if(result is not null)await ApplyWorkerResultAsync(job,result,ct);
        else
        {
            var err=Safe(await process.StandardError.ReadToEndAsync(ct));
            if(File.Exists(FencePath(job)))await QueueReportAsync(job,"recovery_hold",null,false,"worker_exit_without_result_after_fence",err.Length>0?err:"Worker پس از Fence بدون نتیجه پایدار خاتمه یافت.",ct);
            else await QueueReportAsync(job,"failed",null,true,"worker_exit_without_fence",err.Length>0?err:"Worker پیش از Fence بدون نتیجه پایدار خاتمه یافت.",ct);
        }
        CleanupWorkerFiles(job);return true;
    }

    private async Task<WorkerResult?> TryReadWorkerResultAsync(LocalJob job,CancellationToken ct)
    {
        var path=ResultPath(job);if(!File.Exists(path))return null;
        try
        {
            var result=JsonSerializer.Deserialize<WorkerResult>(await File.ReadAllTextAsync(path,ct),AgentOptions.JsonOptions());
            if(result is null||result.ServerJobId!=job.ServerJobId||result.AttemptId!=job.AttemptId||!string.Equals(result.LocalReceiptId,job.LocalReceiptId,StringComparison.Ordinal)||!string.Equals(result.ContentSha256,job.ContentSha256,StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Durable Worker result با Attempt محلی تطابق ندارد.");
            return result;
        }
        catch(Exception e){LogSafe("worker_result_validation",e);return null;}
    }

    private async Task ApplyWorkerResultAsync(LocalJob job,WorkerResult result,CancellationToken ct)
    {
        if(result.Status=="submitted")
        {
            if(string.IsNullOrWhiteSpace(result.SpoolerJobId)){await QueueReportAsync(job,"recovery_hold",null,false,"submitted_without_spooler_id","Worker وضعیت submitted بدون Spooler Job ID ثبت کرده است.",ct);return;}
            _lastSubmission=DateTimeOffset.UtcNow;await _store.SetStateAsync(job.AttemptId,LocalJobState.Submitted,result.SpoolerJobId,ct:ct);await QueueReportAsync(job,"submitted",result.SpoolerJobId,false,null,null,ct);
        }
        else if(result.Status=="failed")
        {await _store.SetStateAsync(job.AttemptId,LocalJobState.SafeFailed,error:result.ErrorMessage,ct:ct);await QueueReportAsync(job,"failed",null,result.Retryable,result.ErrorCode,result.ErrorMessage,ct);}
        else if(result.Status=="unknown")
        {await _store.SetStateAsync(job.AttemptId,LocalJobState.Unknown,result.SpoolerJobId,result.ErrorMessage,ct:ct);await QueueReportAsync(job,"unknown",result.SpoolerJobId,false,result.ErrorCode,result.ErrorMessage,ct);}
        else
        {await _store.SetStateAsync(job.AttemptId,LocalJobState.RecoveryHold,result.SpoolerJobId,result.ErrorMessage,ct:ct);await QueueReportAsync(job,"recovery_hold",result.SpoolerJobId,false,result.ErrorCode??"worker_recovery_hold",result.ErrorMessage,ct);}
    }

    private async Task QueueReportAsync(LocalJob job,string status,string? spooler,bool retryable,string? code,string? message,CancellationToken ct)
    {
        if(await _store.HasPendingReportAsync(job.AttemptId,ct))return;
        var requestId=CryptoUtil.NewRequestId();var body=JsonSerializer.Serialize(new{status,spooler_job_id=spooler,retryable,error_code=code,error_message=message},AgentOptions.JsonOptions());
        await _store.EnqueueReportAsync(job.ServerJobId,job.AttemptId,requestId,body,ct);
        var state=status=="submitted"?LocalJobState.ReportPending:status=="unknown"?LocalJobState.Unknown:status=="recovery_hold"?LocalJobState.RecoveryHold:LocalJobState.ReportPending;
        await _store.SetStateAsync(job.AttemptId,state,spooler,message,ct:ct);
    }

    private async Task FlushReportsAsync(CancellationToken ct)
    {
        if(_api is null)return;
        foreach(var row in await _store.PendingReportsAsync(20,ct))
        {
            var job=await _store.GetByAttemptAsync(row.AttemptId,ct);if(job is null){await _store.MarkReportErrorAsync(row.Id,"Local attempt برای report پیدا نشد.",ct);continue;}
            try
            {
                using var doc=JsonDocument.Parse(row.BodyJson);var root=doc.RootElement;var status=root.GetProperty("status").GetString()??"recovery_hold";
                var spooler=root.TryGetProperty("spooler_job_id",out var sp)&&sp.ValueKind==JsonValueKind.String?sp.GetString():null;var retryable=root.TryGetProperty("retryable",out var rr)&&rr.ValueKind==JsonValueKind.True;
                var code=root.TryGetProperty("error_code",out var ec)&&ec.ValueKind==JsonValueKind.String?ec.GetString():null;var msg=root.TryGetProperty("error_message",out var em)&&em.ValueKind==JsonValueKind.String?em.GetString():null;
                var result=await _api.ReportAsync(job,row.RequestId,status,spooler,retryable,code,msg,ct);if(result.Success)await _store.MarkReportSentAsync(row.Id,row.AttemptId,ct);else await _store.MarkReportErrorAsync(row.Id,Safe(result.Message??result.Code??"Server report rejected."),ct);
            }
            catch(Exception e){await _store.MarkReportErrorAsync(row.Id,Safe(e.Message),ct);}
        }
    }

    private async Task MaybeHeartbeatAsync(CancellationToken ct)
    {
        if(_api is null||DateTimeOffset.UtcNow<_nextHeartbeat)return;
        var p=new HeartbeatPayload(CryptoUtil.NewRequestId(),Environment.MachineName,AgentVersion,Environment.OSVersion.VersionString,(long)(DateTimeOffset.UtcNow-_started).TotalSeconds,_lastPoll?.ToString("O"),await _store.CountOpenAsync(ct),await _store.CountAmbiguousAsync(ct),_lastSubmission?.ToString("O"),"ok",DiskFreeMb(),true,true,true,SafeQueues().ToList());
        await _api.HeartbeatAsync(p,ct);_nextHeartbeat=DateTimeOffset.UtcNow.AddSeconds(_options.HeartbeatSeconds);
    }

    private async Task WriteLocalHealthAsync(string state,bool configOk,bool secretOk,string? error,CancellationToken ct)
    {
        try
        {
            var serviceAccount=OperatingSystem.IsWindows()&&WindowsIdentity.GetCurrent().IsSystem;
            var snapshot=new LocalHealthSnapshot(AgentVersion,Environment.MachineName,state,configOk,secretOk,serviceAccount,error,DateTimeOffset.UtcNow.ToString("O"),await _store.CountOpenAsync(ct),await _store.CountAmbiguousAsync(ct),SafeQueues().ToList());
            await DurableFile.WriteJsonAtomicAsync(_paths.HealthPath,snapshot,ct);
        }
        catch(Exception e){_log.LogWarning("health.json: {Type}: {Message}",e.GetType().Name,Safe(e.Message));}
    }

    private IReadOnlyList<PrinterQueueHealth> SafeQueues(){try{return _printers.GetQueues();}catch(Exception e){LogSafe("printer_health",e);return [];}}
    private static bool QueueReady(PrinterQueueHealth p,string queue)=>string.Equals(p.Name,queue,StringComparison.OrdinalIgnoreCase)&&!p.Offline&&!p.Paused&&!p.PaperOut&&!p.Error;
    private long DiskFreeMb(){try{var root=Path.GetPathRoot(_paths.ProgramDataRoot);return root is null?0:new DriveInfo(root).AvailableFreeSpace/1024/1024;}catch{return 0;}}
    private string InputPath(LocalJob j)=>Path.Combine(_paths.WorkPath,$"input-{j.ServerJobId}-{j.AttemptId}.json");
    private string ResultPath(LocalJob j)=>Path.Combine(_paths.WorkPath,$"result-{j.ServerJobId}-{j.AttemptId}.json");
    private string FencePath(LocalJob j)=>Path.Combine(_paths.WorkPath,$"fence-{j.ServerJobId}-{j.AttemptId}.dat");
    private string StartSignalPath(LocalJob j)=>Path.Combine(_paths.WorkPath,$"start-{j.ServerJobId}-{j.AttemptId}.dat");
    private void CleanupTransientBeforeLaunch(LocalJob j){TryDelete(InputPath(j));TryDelete(ResultPath(j));TryDelete(FencePath(j));TryDelete(StartSignalPath(j));}
    private void CleanupWorkerFiles(LocalJob j){TryDelete(InputPath(j));TryDelete(ResultPath(j));TryDelete(FencePath(j));TryDelete(StartSignalPath(j));}
    private void LogSafe(string area,Exception e){_log.LogError("{Area}: {Type}: {Message}",area,e.GetType().Name,Safe(e.Message));try{_fileLog.Error(area,e);}catch(Exception logError){_log.LogError("FileLog: {Type}: {Message}",logError.GetType().Name,Safe(logError.Message));}}
    private static string Safe(string s)=>s.Length>400?s[..400]:s;private static void TryDelete(string p){try{if(File.Exists(p))File.Delete(p);}catch{}}private static void TryKill(Process p){try{if(!p.HasExited)p.Kill(true);}catch{}}
}
